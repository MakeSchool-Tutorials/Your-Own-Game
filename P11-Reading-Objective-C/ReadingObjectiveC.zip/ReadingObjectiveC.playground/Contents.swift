/*:
# Creating a class

Create the following Objective-C class in Swift.


## Pet.h

    @interface Pet : NSObject

    - (id)initWithName:(NSString*)name;
    - (id)initWithName:(NSString*)name andNoise:(NSString*)noise;
    - (void)makeNoise:(NSInteger)noise;
    - (void)eat;
    - (void)eat:(NSInteger)eatTimes andMakeNoise:(NSInteger)noiseTimes;

    @property NSString *name;
    @property NSString *noise;

    @end


## Pet.m

    @implementation Pet {
        NSInteger numberOfTimesFed;
    }

    - (id)init {
        return [self initWithName:@"Nameless" andNoise:@"*silence*"];
    }

    - (id)initWithName:(NSString*)name {
        return [self initWithName:name andNoise:@"*silence*"];
    }

    - (id)initWithName:(NSString*)name andNoise:(NSString*)noise {
        self = [super init];

        if (self) {
            self.name = name;
            self.noise = noise;
        }

        return self;
    }

    - (void)makeNoise:(NSInteger)times {
        for (int i = 0; i < times; i++) {
            NSLog(self.noise);
        }
    }

    - (void)eat {
        // replaces %@ with the value of self.name
        NSLog(@"%@ is eating!", self.name);
        numberOfTimesFed++;
    }

    - (void)eat:(NSInteger)eatTimes andMakeNoise:(NSInteger)noiseTimes {
        for (int i = 0; i < eatTimes; i++) {
            [self eat];
        }
        [self makeNoise:noiseTimes];
    }

    @end

*/





/*:
# Creating a subclass

Create the following Objective-C subclass in Swift.


## Cat.h

    @interface Cat : Pet

    @end


## Cat.m

    @implementation Cat

    - (id)initWithName:(NSString*)name {
        return [self initWithName:name andNoise:@"Meow!"];
    }

    @end

*/





/*:
# Initializing objects and calling methods

Test out your new classes by translating the following code into Swift.


    Cat *webster = [[Cat alloc] initWithName:@"Webster"];
    Pet *holmes = [[Pet alloc] initWithName:@"Holmes" andNoise:@"Woof!"];

    // Cat named Webster
    [webster eat];
    [webster eat];
    [webster eat];
    [webster makeNoise:4];

    // Pet named Holmes makes a "Woof!" noise
    // Likely a dog
    [holmes eat];
    [holmes makeNoise:2];

    // Webster eats again because he is a fat cat
    [webster eat:5 andMakeNoise:3];
*/












































































































/*:

# Solution

    class Pet {
      let name: String
      let noise: String
      var numberOfTimesFed = 0
      
      convenience init() {
        self.init(name: "Nameless", noise: "*silence*")
      }
      
      convenience init(name: String) {
        self.init(name: name, noise: "*silence*")
      }
      
      init(name: String, noise: String) {
        self.name = name
        self.noise = noise
      }
      
      func makeNoise(times: Int) {
        for i in 0..<times {
          println(noise)
        }
      }
      
      func eat() {
        println("\(name) is eating!")
        numberOfTimesFed++
      }
      
      func eat(eatTimes: Int, andMakeNoise noiseTimes: Int) {
        for i in 0..<eatTimes {
          eat()
        }
        makeNoise(noiseTimes)
      }
    }

    class Cat: Pet {
      init(name: String) {
        super.init(name: name, noise: "Meow!")
      }
    }

    let webster = Cat(name: "Webster")
    let holmes = Pet(name: "Holmes", noise: "Woof!")

    webster.eat()
    webster.eat()
    webster.eat()
    webster.makeNoise(4)

    holmes.eat()
    holmes.makeNoise(2)

    webster.eat(5, andMakeNoise: 3)

*/
